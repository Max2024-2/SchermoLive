import ReplayKit
import CoreImage
import UIKit

final class SampleHandler: RPBroadcastSampleHandler {
    private var task: URLSessionWebSocketTask?
    private let ciContext = CIContext()
    private var lastSent = Date.distantPast
    private var sending = false
    private let lock = NSLock()

    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {
        guard let url = URL(string: Config.ingestURL) else {
            finishBroadcastWithError(NSError(domain: "SchermoLive", code: 1,
                userInfo: [NSLocalizedDescriptionKey: "URL del server non valido"]))
            return
        }
        task = URLSession.shared.webSocketTask(with: url)
        task?.resume()
    }

    override func broadcastFinished() {
        task?.cancel(with: .goingAway, reason: nil)
    }

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with type: RPSampleBufferType) {
        guard type == .video, let pixels = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Circa 10 fotogrammi al secondo, e solo se l'invio precedente è finito.
        let now = Date()
        guard now.timeIntervalSince(lastSent) >= 0.1 else { return }
        lock.lock()
        if sending { lock.unlock(); return }
        sending = true
        lock.unlock()
        lastSent = now

        var image = CIImage(cvPixelBuffer: pixels)
        let scale = 540 / image.extent.width
        if scale < 1 { image = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale)) }

        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let jpeg = ciContext.jpegRepresentation(
                of: image, colorSpace: colorSpace,
                options: [kCGImageDestinationLossyCompressionQuality as CIImageRepresentationOption: 0.5])
        else { finishSending(); return }

        task?.send(.data(jpeg)) { [weak self] _ in self?.finishSending() }
    }

    private func finishSending() {
        lock.lock(); sending = false; lock.unlock()
    }
}
