import Foundation

enum Config {
    /// Pagina web che mostra lo schermo (link e QR code nell'app).
    static let viewerURL = "https://schermo-live-ab12.onrender.com/view"
    /// Server WebSocket che riceve i fotogrammi JPEG dall'estensione.
    static let ingestURL = "wss://schermo-live-ab12.onrender.com/ingest"
}