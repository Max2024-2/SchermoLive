import SwiftUI

@main
struct SchermoLiveApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
