import SwiftUI
import ReplayKit
import CoreImage.CIFilterBuiltins

final class PickerHolder: ObservableObject {
    let view: RPSystemBroadcastPickerView

    init() {
        view = RPSystemBroadcastPickerView(frame: CGRect(x: 0, y: 0, width: 44, height: 44))
        view.preferredExtension = (Bundle.main.bundleIdentifier ?? "") + ".broadcast"
        view.showsMicrophoneButton = false
    }

    /// Simula il tocco sul pulsante interno del selettore di sistema.
    func trigger() {
        for sub in view.subviews {
            if let b = sub as? UIButton { b.sendActions(for: .allTouchEvents) }
        }
    }
}

struct PickerView: UIViewRepresentable {
    let holder: PickerHolder
    func makeUIView(context: Context) -> RPSystemBroadcastPickerView { holder.view }
    func updateUIView(_ uiView: RPSystemBroadcastPickerView, context: Context) {}
}

struct ContentView: View {
    @StateObject private var picker = PickerHolder()
    @State private var copied = false

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                Text("Schermo Live").font(.largeTitle.bold())
                Text("Premi il pulsante, scegli «Schermo Live» e tocca «Avvia trasmissione». Poi puoi uscire dall'app e usare il telefono: la condivisione continua.")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)

                Button { picker.trigger() } label: {
                    Label("Avvia condivisione", systemImage: "play.circle.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)

                if let img = qrImage(Config.viewerURL) {
                    Image(uiImage: img)
                        .interpolation(.none)
                        .resizable()
                        .frame(width: 220, height: 220)
                        .padding(12)
                        .background(Color.white)
                        .cornerRadius(12)
                }

                Text(Config.viewerURL)
                    .font(.footnote.monospaced())
                    .multilineTextAlignment(.center)
                    .textSelection(.enabled)

                Button(copied ? "Copiato ✓" : "Copia link") {
                    UIPasteboard.general.string = Config.viewerURL
                    copied = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { copied = false }
                }
                .buttonStyle(.bordered)

                Text("Per fermare: tocca la barra rossa in alto e scegli «Interrompi».")
                    .font(.footnote)
                    .foregroundColor(.secondary)

                PickerView(holder: picker).frame(width: 1, height: 1).opacity(0.01)
            }
            .padding(20)
        }
    }

    private func qrImage(_ text: String) -> UIImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(text.utf8)
        filter.correctionLevel = "M"
        guard let out = filter.outputImage?.transformed(by: CGAffineTransform(scaleX: 10, y: 10)),
              let cg = CIContext().createCGImage(out, from: out.extent) else { return nil }
        return UIImage(cgImage: cg)
    }
}
