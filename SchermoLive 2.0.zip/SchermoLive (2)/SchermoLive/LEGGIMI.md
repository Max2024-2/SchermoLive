# Schermo Live

1. Crea un repository GitHub e carica tutto il contenuto di questa cartella (compresa `.github`).
2. Apri la scheda Actions, scegli «Build IPA» e premi Run workflow.
3. A fine build scarica l'artifact `SchermoLive-ipa`: contiene `SchermoLive.ipa` NON firmato.
4. Firmalo e installalo dal PC con Sideloadly (Apple ID gratuito, valido 7 giorni) oppure con un account Apple Developer.

Prima della build modifica:
- `SchermoLive/Config.swift`: viewerURL e ingestURL con i tuoi indirizzi.
- `project.yml`: sostituisci `com.example` con un identificatore tuo (app e estensione, l'estensione deve restare `<app>.broadcast`).

## Server (cartella `server`)
Node.js 18+. In locale: `cd server && npm install && npm start`.
Su Render: nuovo Web Service dal repository, Root Directory `server`, Build `npm install`, Start `npm start`.
Poi in `Config.swift` usa l'indirizzo ottenuto:
-static let viewerURL = "https://schermo-live-ab12.onrender.com/view"
static let ingestURL = "wss://schermo-live-ab12.onrender.com/ingest"
Attenzione: chiunque conosca l'indirizzo può inviare e vedere lo schermo; non condividerlo pubblicamente.
