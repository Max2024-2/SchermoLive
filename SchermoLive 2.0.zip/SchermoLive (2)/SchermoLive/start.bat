@echo off
title Schermo Live - Server

cd /d "%~dp0"

if exist "server\package.json" goto :trovato_sub
if exist "package.json" goto :trovato_qui

echo Non trovo il server.
echo Cartella corrente: %CD%
echo Metti start.bat nella cartella del progetto, accanto a "server",
echo oppure dentro "server" dove c'e package.json.
echo.
pause
exit /b 1

:trovato_sub
cd server

:trovato_qui
echo Cartella server: %CD%
echo.

where node >nul 2>nul
if errorlevel 1 goto :no_node

if exist node_modules goto :avvio
echo Installazione delle dipendenze...
call npm install
if errorlevel 1 goto :err_npm

:avvio
start "" cmd /c "timeout /t 4 /nobreak >nul && start http://localhost:3000/view"
echo Avvio del server - premi Ctrl+C per fermarlo
echo Pagina: http://localhost:3000/view
echo.
call npm start
echo.
echo Il server si e' fermato. Leggi l'errore qui sopra.
pause
exit /b 0

:no_node
echo Node.js non e' installato.
echo Scaricalo da https://nodejs.org versione 18 o superiore, poi riavvia.
pause
exit /b 1

:err_npm
echo Errore durante npm install. Leggi il messaggio qui sopra.
pause
exit /b 1
